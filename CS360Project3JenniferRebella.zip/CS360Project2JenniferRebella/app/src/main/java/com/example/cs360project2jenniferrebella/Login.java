package com.example.cs360project2jenniferrebella;

public class Login {

    private String username;



    public String getUsername() {
        return username;
    }

    private String password;

    public String getPassword() {
        return password;
    }
    public Login(String username, String password) {
        this.username = username;
        this.password = password;
    }


}
