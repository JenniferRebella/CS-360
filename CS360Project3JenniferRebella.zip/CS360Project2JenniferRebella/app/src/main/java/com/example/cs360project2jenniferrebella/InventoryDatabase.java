package com.example.cs360project2jenniferrebella;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase  extends SQLiteOpenHelper {

    private static final int VERSION = 1;

    private static final String DATABASE_NAME = "inventory.db";

    private static InventoryDatabase instance;

    private InventoryDatabase(Context context){ super(context,
            DATABASE_NAME,
            null,
            VERSION);}
    public static InventoryDatabase getInstance(Context context){
        if (instance == null){
            instance = new InventoryDatabase(context);
        }
        return instance;
    }
    private static final class InventoryTable{
        private static final String USERNAME = getUsername();

        private static final String TABLE = "inventory";

        private static final String COL_ID1 = "_id";

        private static final String COL_ID2 = "_name";

        private static final String COL_ID3 = "_qty";

        private static final String COL_ID4 = "_desc";

        private static final String COL_NAME1 = "ID";

        private  static final String COL_NAME2 = "Name";

        private static final String COL_NAME3 = "Qty.";

        private static final String COL_NAME4 = "Decs.";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE +
                "( "+ InventoryTable.COL_ID1 + "interger primary key autoincrement," +
                InventoryTable.COL_NAME1 + InventoryTable.COL_ID2 + InventoryTable.COL_NAME2 + InventoryTable.COL_ID3 + InventoryTable.COL_NAME3 +
                InventoryTable.COL_ID4 + InventoryTable.COL_NAME4);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " +  InventoryTable.TABLE);
        onCreate(db);
    }

    public List<Inventory> getInventory(){
        List<Inventory> items = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM " + InventoryTable.TABLE;

        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()){
            do{
                long id = cursor.getInt(0);
                String name = cursor.getString(1);
                String qty = cursor.getString(2);
                String desc = cursor.getString(3);
                Inventory item = new Inventory(id, name, qty, desc);
                Inventory.add(item);

            }while (cursor.moveToNext());

        }
        return items;
    }
    public Inventory getInventory(long itemId) {
        Inventory item = null;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + InventoryTable.TABLE + "WHERE " + InventoryTable.COL_ID1 ;
        Cursor cursor = db.rawQuery(sql, new String[]{Long.toString(itemId)});

        if (cursor.moveToFirst()) {
            String name = cursor.getString(1);
            String qty = cursor.getString(2);
            String desc = cursor.getString(3);
            item = new Inventory(itemId, name, qty, desc);
        }
        return item;
    }
    public long addInventory(Inventory item){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(InventoryTable.COL_NAME2, item.getName());
        values.put(InventoryTable.COL_NAME3, item.getQty());
        values.put(InventoryTable.COL_NAME4, item.getDesc());
        long newID = db.insert(InventoryTable.TABLE, null, values);

        return newID;

    }
    public boolean editInventory(long id, Inventory item){
        boolean isEdited = false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(InventoryTable.COL_NAME1, id);
        values.put(InventoryTable.COL_NAME2, item.getName());
        values.put(InventoryTable.COL_NAME3, item.getQty());
        values.put(InventoryTable.COL_NAME4, item.getDesc());
        int result = db.insert(InventoryTable.TABLE, values, InventoryTable.COL_ID1 + " = " + id, InventoryTable.COL_ID2 + " = " = item.getName());

        return result ==1;
    }
    public boolean deleteInventory(Long id){
        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(InventoryTable.TABLE,values, InventoryTable.COL_ID1 + " = " + id, InventoryTable.COL_ID2 + " = " = item.getName());

        return result ==1;
    }

    }


